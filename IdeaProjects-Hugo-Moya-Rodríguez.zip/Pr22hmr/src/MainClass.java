import Info_Producto.Producto;

import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
    Producto Prácticas_de_entornos_de_desarrollo_Tema_2 = new Producto("01", "Prácticas_de_entornos_de_desarrollo_Tema_2", 20);
        System.out.println("El producto de código "+ Prácticas_de_entornos_de_desarrollo_Tema_2.getCodigo()+ " y nombre "+ Prácticas_de_entornos_de_desarrollo_Tema_2.getNombre()+ " tiene de precio "+ Prácticas_de_entornos_de_desarrollo_Tema_2.getPrecio()+ " euros");
        Producto Entornos_integrados_de_desarrollo = new Producto("01", "Entornos_integrados_de_desarrollo", 20);
        System.out.println("El producto de código "+ Entornos_integrados_de_desarrollo.getCodigo()+ " y nombre "+ Entornos_integrados_de_desarrollo.getNombre()+ " tiene de precio "+ Entornos_integrados_de_desarrollo.getPrecio()+ " euros");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un código: ");
        String codigo = scanner.nextLine();

        System.out.print("Ingrese un nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Ingrese un precio: ");
        double precio = scanner.nextDouble();
        System.out.println("El producto de código "+ codigo + " y nombre "+ nombre + " tiene de precio "+ precio + " euros");
    }
}
